#! /bin/bash
echo >&2 $@
exit 0
